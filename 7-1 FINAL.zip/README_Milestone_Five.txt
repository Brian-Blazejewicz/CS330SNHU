CS 330 Milestone Five - Brian Blazejewicz

Changes
- Preserves the Milestone Four tree, textures, and camera controls.
- Adds a warm point light and a cool fill light.
- Adds ambient illumination and Phong diffuse/specular lighting.
- Adds a textured ground plane with a modest specular highlight.
- Uses inverse-transpose normals for correctly lit scaled meshes.

INSTALL AND BUILD
1. Back up your existing CS330Content/Projects/7-1_FinalProjectMilestones folder.
2. Copy the contents of this folder into that course project folder.
   Keep the course Libraries, Utilities, and 3DShapes folders in their original
   locations. They are required and were not included in the uploaded ZIP.
3. Open 7-1_FinalProjectMilestones.sln. Select Release and x86 (Win32).
4. Rebuild Solution. The project copies shaders, textures, and glew32.dll into
   the EXE output folder. If the GLEW DLL copy fails, copy the provided
   runtime DLL manually into the output folder.
5. Run from Visual Studio, then run the new EXE directly from its output folder.
   For direct launch, use that folder as the working directory.
6. Check that the ground shows texture and a light highlight, both tree parts
   show their textures, and all surfaces remain visible as you move the camera.
7. Submit your completed course project ZIP, including the newly built EXE,
   shaders, textures, DLL, source, and required course dependencies.

STATUS
Validation: vertex and fragment shaders compiled and linked using a Mesa
OpenGL context; the Visual Studio project XML parsed successfully.
The C++ application could not be built here because the uploaded course
dependencies and Windows Visual Studio toolchain are unavailable.

This package contains updated source, not a newly built Windows executable.
An older EXE is not evidence that these lighting changes work. Build and test
in Visual Studio before submission. The mesh attribute layout assumed here is
position=0, normal=1, UV=2, matching the standard SNHU ShapeMeshes framework.

AI ACKNOWLEDGMENT (review and adapt to your actual use)
I used OpenAI ChatGPT to assist with Phong lighting code, shader updates,
material settings, and packaging instructions. I reviewed the changes and
will compile and test the resulting scene in Visual Studio before submission.
